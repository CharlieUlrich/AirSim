// ready to run example: https://github.com/Microsoft/AirSim/blob/main/HelloDrone/main.cpp

#include <iostream>
#include "vehicles/multirotor/api/MultirotorRpcLibClient.hpp"

using namespace std;
int main()
{
    //for (TActorIterator<AActor> actor(GetWorld()); actor; ++actor) {
        //Do whatever you wantwith y our actor
    //    actor->BlahBlah();
   // }
    msr::airlib::MultirotorRpcLibClient client;

    std::cout << "Press Enter to enable API control\n";
    std::cin.get();
    client.enableApiControl(true);

    std::cout << "Press Enter to arm the drone\n";
    std::cin.get();
    client.armDisarm(true);

    std::cout << "Press Enter to takeoff\n";
    std::cin.get();
    client.takeoffAsync(5)->waitOnLastTask();

    std::cout << "Press Enter to fly down first path\n";
    std::cin.get();
    auto position = client.getMultirotorState().getPosition(); // from current location
    //Units in unreal are cm and in their commands are meters so have to divide movement by 100
    client.moveToPositionAsync(position.x() + 15, position.y() - 14, position.z() - 1, 3)->waitOnLastTask();
    position = client.getMultirotorState().getPosition(); // from current location
    client.moveToPositionAsync(position.x() + 7, position.y() - 11, position.z() - 2, 3)->waitOnLastTask();
    position = client.getMultirotorState().getPosition(); // from current location
    client.moveToPositionAsync(position.x() + 9, position.y() - 5, position.z() - 1, 3)->waitOnLastTask();
    position = client.getMultirotorState().getPosition(); // from current location
    client.moveToPositionAsync(position.x() - 2, position.y() - 15, position.z() - 5, 3)->waitOnLastTask();
    position = client.getMultirotorState().getPosition(); // from current location
    client.moveToPositionAsync(position.x() - 8, position.y() - 22, position.z() - 10, 3)->waitOnLastTask();
    position = client.getMultirotorState().getPosition(); // from current location
   
    std::cout << "Press Enter to Keep Going\n";
    std::cin.get();
    client.moveToPositionAsync(position.x() - 44, position.y() - 33, position.z(), 3)->waitOnLastTask();
    position = client.getMultirotorState().getPosition(); // from current location
    client.moveToPositionAsync(position.x() - 9, position.y() + 6, position.z() + 1, 3)->waitOnLastTask();
    position = client.getMultirotorState().getPosition(); // from current location
    client.moveToPositionAsync(position.x(), position.y() + 12, position.z() + 1, 3)->waitOnLastTask();
    position = client.getMultirotorState().getPosition(); // from current location
    client.moveToPositionAsync(position.x() + 5, position.y() + 5, position.z() + 3, 3)->waitOnLastTask();
    position = client.getMultirotorState().getPosition(); // from current location
    client.moveToPositionAsync(position.x(), position.y() + 8, position.z(), 3)->waitOnLastTask();
    position = client.getMultirotorState().getPosition(); // from current location
    client.moveToPositionAsync(position.x() + 25, position.y() + 25, position.z() + 6, 3)->waitOnLastTask();
    position = client.getMultirotorState().getPosition(); // from current location

    std::cout << "Press Enter to Return to start\n";
    std::cin.get();
    client.moveToPositionAsync(position.x() - 52, position.y() + 14, position.z() - 2, 3)->waitOnLastTask();
    position = client.getMultirotorState().getPosition(); // from current location
    client.moveToPositionAsync(position.x(), position.y() + 27, position.z() + 3, 3)->waitOnLastTask();
    position = client.getMultirotorState().getPosition(); // from current location
    client.moveToPositionAsync(position.x() + 25, position.y() + 27, position.z() + 10, 3)->waitOnLastTask();
    position = client.getMultirotorState().getPosition(); // from current location
    client.moveToPositionAsync(position.x() + 25, position.y() - 25, position.z(), 3)->waitOnLastTask();
    position = client.getMultirotorState().getPosition(); // from current location

    std::cout << "Press Enter to land\n";
    std::cin.get();
    client.landAsync()->waitOnLastTask();

    return 0;
}